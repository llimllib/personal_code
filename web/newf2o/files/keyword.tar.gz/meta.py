"""Creates meta information about a file

Right now, it only reads any C{<!--keyword: x,y,z -->}
lines in a file and pickles them into meta_dir.

There are two configuration options:

    - meta_dir: Directory in which to store meta information
    - all_keywords: If true, generate a list of all keywords in
                    C{data['meta']['all_keywords']}

Is there any other metadata that could be implemented this way? If you have
an idea, drop me a line.
"""

__author__ = "Bill Mill - bill.mill@gmail.com"
__version__ = "0.1"
__url__ = "http://llimllib.f2o.org/blog"
__description__ = "Provides a pyblosxom keyword system"

from Pyblosxom import tools
import os, cPickle

#for debugging
#tools.make_logger('c:/code/web/newf2o/blog/log/pyblosxom.log')
#log = tools.log

def verify_installation(request):
    """This is for verifying that this is installed correctly."""
    #what to put here?
    return 1

#keep this global so the recursive function can always get it
meta_dir = ''

def cb_start(args):
    """sets up meta information

    Called at plugin initialization, this function starts the recursive data
    directory search. It calls walkmeta for every directory it finds.

    @param args: A dictionary containing the request object
    @type args: Dictionary
    @return: None
    """
    config = args['request'].getConfiguration()
    data = args['request'].getData()

    data['meta'] = {}

    datadir = config['datadir']
    global meta_dir 
    meta_dir = config.get('meta_dir', '')
    all_keywords = config.get('all_keywords', 0)

    if not meta_dir or not os.path.isdir(meta_dir):
        raise "You need to specify a valid py[meta_dir] in your config.py"

    os.path.walk(datadir, walkmeta, data)

    base = config['base_url']
    kwlist = []
    if all_keywords:
        for file_ in data['meta']:
            for kw in data['meta'][file_].get('keywords', ''):
                if kw not in kwlist:
                    kwlist.append(kw)
        kwlist.sort()
        for i in range(len(kwlist)):
            kwlist[i] = '<a href="%s/keyword/%s">%s</a><br>\n' % \
                (base, kwlist[i], kwlist[i])

        config['all_keywords'] = ''.join(kwlist)

def walkmeta(data, dirname, fnames):
    """Loads meta data if it exists, creates it if not

    Called on each directory in the datadir, simply makes sure that each *.txt
    file has a corresponding *.meta file. If not, it calls the parse function 
    and creates the file.

    @param data: A reference to the requests' data dictionary
    @type data: Dictionary

    @param dirname: The name of the current directory
    @type dirname: String

    @param fnames: The names of the files in the current directory
    @type fnames: List

    @return: None; stores data in the data['meta'] dictionary
    """
    #TODO: should .txt be a configuration option?
    for f in fnames:
        if f.endswith('.txt'):
            pickle = meta_dir + '/' + f.replace('.txt', '.meta')
            f = dirname + '/' + f
            f = f.replace('\\', '/')
            if os.path.isfile(pickle):
                #TODO: use protocol 1 or 2 to speed it up?
                data['meta'][f] = cPickle.load(file(pickle, 'r'))
            else:
                md = parsemeta(file(f, 'r'))
                data['meta'][f] = md
                pickle = file(pickle, 'w')
                cPickle.dump(md, pickle)
                pickle.close()

def parsemeta(f):
    """Parse an opened file and return any keywords

    Should eventually read arbitrary meta information from the file. But how?

    @params f: An open file
    @type f: File
    @return: A dictionary where 'keywords' references a list of keywords
    """
    keyw = []
    for line in f:
        if line.lower().startswith('<!--keywords:') and line.endswith('-->\n'):
            keyw = line[13:-4].strip().split(',')
            break
    keyw = [kw.strip() for kw in keyw] #strip all elts of keyw
    return {'keywords': keyw}
