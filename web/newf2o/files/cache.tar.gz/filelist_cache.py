"""A caching system for pyblosxom. Works by storing the result of the fileentry
callback in cache_dir.

Configuration variables:
cache_dir: Directory in which to store cache files
cache_to:  Cache timeout in minutes"""

import cPickle, os
from Pyblosxom import tools

def pathjoin(*paths):
    return '/'.join(paths)

def get_cache(filename):
    """Load the cache of a file
    
    @param filename: The name of the file to check for a cache
    @type filename: String
    
    @returns: The associated cache Dictionary if it exists, else {}
    """
    try:
        f = file(filename, 'rb')
        tools.lock(f, tools.LOCK_EX)
        c = cPickle.load(f)
        f.close()
    except IOError: c = {}
    return c

def put_cache(cache, filename):
    """Write L{cache} to L{filename}

    @param cache: Dictionary to store in cache
    @type cache: Dictionary

    @param filename: name of file to put the cache in
    @type filename: String

    @returns: None
    """
    for c in cache['filelist']:
        c.getMetadata('')
        c._request = None
    try:
        f = file(filename, 'wb')
    except IOError:
        os.makedirs(os.path.split(filename)[0])
        f = file(filename, 'wb')
    tools.lock(f, tools.LOCK_EX)
    cb = cPickle.Pickler(f, -1)
    cb.dump(cache)
    f.close()
