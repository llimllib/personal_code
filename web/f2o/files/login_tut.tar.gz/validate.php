<?php
	session_start();
?>
<html>
<head>
<title>validate.php</title>
</head>
<body>
<?php
	$db_user = 'bill';
	$db_pass = 'ginger22';
	$user_name = $_POST['user_name'];
	$password = $_POST['password'];

	//connect to the DB and select the "dictator" database
	$connection = mysql_connect('localhost', $db_user, $db_pass) or die(mysql_error());
	mysql_select_db('dictators', $connection) or die(mysql_error());

	//set up the query
	$query = "SELECT * FROM users 
			WHERE user_name='$user_name' AND password='$password'";
			
	//run the query and get the number of affected rows
	$result = mysql_query($query, $connection) or die('error making query');
	$affected_rows = mysql_num_rows($result);

	//if there's exactly one result, the user is validated. Otherwise, he's invalid
	if($affected_rows == 1) {
		$_SESSION['user_name'] = $user_name;
		print 'validated';
	}
	else {
		print 'not valid';
	}
?>
</body>
</html>
