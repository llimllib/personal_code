<html>
<head>
<title>login.html</title>
</head>
<body>
<form name="login" method="post" action="validate.php">
username:<input type="text" name="user_name"><br>
password:<input type="password" name="password"><br>
<input type="submit" value="submit">
</form>
</body>
</html>
